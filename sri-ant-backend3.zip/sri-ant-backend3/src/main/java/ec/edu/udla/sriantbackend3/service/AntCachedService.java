package ec.edu.udla.sriantbackend3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class AntCachedService {

    @Autowired
    private AntRemoteService antRemoteService;

    /**
     * Patrón Proxy + Cache-Aside:
     * - Primero revisa el caché "antCache" por cédula.
     * - Si NO hay, llama a la ANT, guarda la respuesta y la devuelve.
     */
    @Cacheable(value = "antCache", key = "#cedula")
    public Mono<String> obtenerPuntosConCache(String cedula) {
        return antRemoteService.consultarPuntos(cedula);
    }
}
