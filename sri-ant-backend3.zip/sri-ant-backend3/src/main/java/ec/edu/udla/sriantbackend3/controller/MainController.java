package ec.edu.udla.sriantbackend3.controller;

import ec.edu.udla.sriantbackend3.service.AntCachedService;
import ec.edu.udla.sriantbackend3.service.SriService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MainController {

    @Autowired
    private SriService sriService;

    @Autowired
    private AntCachedService antCachedService;

    @GetMapping("/")
    public String formulario() {
        return "formulario";
    }

    @PostMapping("/consultar")
    public String consultar(
            @RequestParam String email,
            @RequestParam String ruc,    // aquí usuario mete cédula o ruc
            @RequestParam String placa,
            Model model) {

        // 1) Verificar si existe contribuyente
        String existeRespuesta = sriService.existeContribuyente(ruc).block();

        if (existeRespuesta != null && existeRespuesta.startsWith("ERROR_SRI")) {
            model.addAttribute("error", "Error llamando al SRI: " + existeRespuesta);
            return "formulario";
        }

        if (existeRespuesta == null ||
                (!existeRespuesta.equalsIgnoreCase("true")
                        && !existeRespuesta.equalsIgnoreCase("SI"))) {
            model.addAttribute("error", "El RUC/Cédula no corresponde a un contribuyente registrado en el SRI.");
            return "formulario";
        }

        // 2) Datos de contribuyente
        String datosContribuyente = sriService.obtenerContribuyente(ruc).block();

        // 3) Datos de vehículo
        String datosVehiculo = sriService.obtenerVehiculoPorPlaca(placa).block();

        // 4) Puntos de licencia (ANT con caché) usando la cédula (10 dígitos)
        // El link del profe usa la cédula directamente:
        // https://consultaweb.ant.gob.ec/...ps_tipo_identificacion=CED&ps_identificacion=XXXXXXXXX&ps_placa=
        String puntosAnt = antCachedService.obtenerPuntosConCache(ruc).block();

        model.addAttribute("email", email);
        model.addAttribute("ruc", ruc);
        model.addAttribute("datosContribuyente", datosContribuyente);
        model.addAttribute("vehiculo", datosVehiculo);
        model.addAttribute("puntosAnt", puntosAnt);

        return "resultado";
    }
}
