package ec.edu.udla.sriantbackend3.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

@Service
public class SriService {

    private final WebClient sriWebClient;

    public SriService(@Qualifier("sriWebClient") WebClient sriWebClient) {
        this.sriWebClient = sriWebClient;
    }

    /**
     * Convierte lo que ingresa el usuario (cédula o RUC)
     * a un RUC de 13 dígitos para persona natural.
     * - Si tiene 10 dígitos -> agrega "001" al final.
     * - Si tiene 13 dígitos -> lo deja igual.
     */
    private String normalizarRuc(String cedulaORuc) {
        String limpio = cedulaORuc.trim();
        if (limpio.length() == 10) {
            return limpio + "001"; // cédula -> RUC persona natural
        }
        return limpio; // si ya viene en 13 dígitos
    }

    /**
     * 1) Verificar si existe contribuyente en SRI.
     *    Endpoint dado por el profesor:
     *    https://srienlinea.sri.gob.ec/sri-catastro-sujeto-servicio-internet/rest/ConsolidadoContribuyente/existePorNumeroRuc?numeroRuc=
     */
    public Mono<String> existeContribuyente(String cedulaORuc) {
        String ruc = normalizarRuc(cedulaORuc);

        String endpoint =
                "/sri-catastro-sujeto-servicio-internet/rest/ConsolidadoContribuyente/existePorNumeroRuc?numeroRuc="
                        + ruc;

        System.out.println("🔵 SRI - Verificando contribuyente:");
        System.out.println("➡ URL: " + endpoint);

        return sriWebClient.get()
                .uri(endpoint)
                .retrieve()
                .bodyToMono(String.class)
                .doOnNext(respuesta -> {
                    System.out.println("🔵 RESPUESTA SRI:");
                    System.out.println(respuesta);
                })
                .onErrorResume(WebClientResponseException.class, ex -> {
                    System.out.println("🔴 ERROR SRI:");
                    System.out.println("Código: " + ex.getRawStatusCode());
                    System.out.println("Mensaje: " + ex.getResponseBodyAsString());
                    return Mono.just("ERROR_SRI_" + ex.getRawStatusCode());
                });
    }


    /**
     * 2) Obtener información del contribuyente persona natural.
     *    Endpoint dado por el profesor:
     *    https://srienlinea.sri.gob.ec/sri-catastro-sujeto-servicio-internet/rest/ConsolidadoContribuyente/obtenerPorNumerosRuc?&ruc=
     */
    public Mono<String> obtenerContribuyente(String cedulaORuc) {
        String ruc = normalizarRuc(cedulaORuc);

        String endpoint = "/sri-catastro-sujeto-servicio-internet/rest/ConsolidadoContribuyente/obtenerPorNumerosRuc?&ruc="
                + ruc;

        return sriWebClient.get()
                .uri(endpoint)
                .retrieve()
                .bodyToMono(String.class);
    }

    /**
     * 3) Obtener información del vehículo.
     *    Endpoint dado por el profesor:
     *    https://srienlinea.sri.gob.ec/sri-matriculacion-vehicular-recaudacion-servicio-internet/rest/BaseVehiculo/obtenerPorNumeroPlacaOPorNumeroCampvOPorNumeroCpn?numeroPlacaCampvCpn=
     */
    public Mono<String> obtenerVehiculoPorPlaca(String placa) {
        String endpoint =
                "/sri-matriculacion-vehicular-recaudacion-servicio-internet/rest/BaseVehiculo/obtenerPorNumeroPlacaOPorNumeroCampvOPorNumeroCpn?numeroPlacaCampvCpn="
                        + placa.trim();

        return sriWebClient.get()
                .uri(endpoint)
                .retrieve()
                .bodyToMono(String.class);
    }
}
