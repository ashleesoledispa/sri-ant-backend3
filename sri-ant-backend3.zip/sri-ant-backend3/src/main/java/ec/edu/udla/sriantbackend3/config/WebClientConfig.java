package ec.edu.udla.sriantbackend3.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient sriWebClient() {
        return WebClient.builder()
                .baseUrl("https://srienlinea.sri.gob.ec")
                .build();
    }

    @Bean
    public WebClient antWebClient() {
        return WebClient.builder()
                .baseUrl("https://consultaweb.ant.gob.ec")
                .build();
    }
}
