package ec.edu.udla.sriantbackend3.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class AntRemoteService {

    private final WebClient antWebClient;

    public AntRemoteService(@Qualifier("antWebClient") WebClient antWebClient) {
        this.antWebClient = antWebClient;
    }

    /**
     * Endpoint del profesor:
     * https://consultaweb.ant.gob.ec/PortalWEB/paginas/clientes/clp_grid_citaciones.jsp?ps_tipo_identificacion=CED&ps_identificacion=XXXXXXXXX&ps_placa=
     */
    public Mono<String> consultarPuntos(String cedula) {
        String endpoint =
                "/PortalWEB/paginas/clientes/clp_grid_citaciones.jsp?ps_tipo_identificacion=CED&ps_identificacion="
                        + cedula.trim()
                        + "&ps_placa=";

        return antWebClient.get()
                .uri(endpoint)
                .retrieve()
                .bodyToMono(String.class);
    }
}
